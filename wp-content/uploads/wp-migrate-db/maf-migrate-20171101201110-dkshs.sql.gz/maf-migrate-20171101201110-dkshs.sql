# WordPress MySQL database migration
#
# Generated: Wednesday 1. November 2017 20:11 UTC
# Hostname: localhost
# Database: `maf`
# URL: //localhost/razorbee/maf
# Path: /Applications/XAMPP/xamppfiles/htdocs/razorbee/maf
# Tables: wp_commentmeta, wp_comments, wp_e_portfolio, wp_layerslider, wp_layerslider_revisions, wp_links, wp_options, wp_postmeta, wp_posts, wp_revslider_css, wp_revslider_layer_animations, wp_revslider_navigations, wp_revslider_sliders, wp_revslider_slides, wp_revslider_static_slides, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates, wp_yikes_easy_mc_forms, wp_yith_wcwl, wp_yith_wcwl_lists
# Table Prefix: wp_
# Post Types: revision, attachment, carousels, cool_timeline, custom_css, customize_changeset, nav_menu_item, page, post, product, thegem_client, thegem_gallery, thegem_qf_item, thegem_team_person, thegem_testimonial, timelinr, wp-timeline, wpcf7_contact_form
# Protocol: http
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

